package com.mycompany.algoritmia;

/**
 *
 * @author a2211
 */
public class Pila {
    Nodo first;
    Nodo last;
    
    public Pila(){
        this.first = null;
        this.last = null;
    }
    
    public boolean estaVacia (){
        if(first == null && last == null)
        {
            return true;
        } else{
            return false;
        }
    }
    
    public void apilar(int dato)
    {
        Nodo nuevoNodo = new Nodo(dato);
        if(estaVacia()){
            first = nuevoNodo;
            last = nuevoNodo;
        } else{
            nuevoNodo.setSiguiente(first);
            first = nuevoNodo;
        }
    }
    
    public int desapilar(){
        if(!estaVacia()){
            int valor = first.getDato();
            
            Nodo temp = first;
            first = first.getSiguiente();
            
            return valor;
        } else {
            return -1;
        }
    }
    
    public void imprimir(){
        if(estaVacia()){
            int valor = first.getDato();
            
        } else {
            int valor = last.getDato();
        }
    }
}
