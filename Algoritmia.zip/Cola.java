package com.mycompany.algoritmia;

/**
 *
 * @author a2211
 */
public class Cola {
    Nodo first;
    Nodo last;
    
    public Cola(){
        this.first = null;
        this.last = null;
    }
    
    public boolean estaVacia (){
        if(first == null && last == null)
        {
            return true;
        } else{
            return false;
        }
    }
}
