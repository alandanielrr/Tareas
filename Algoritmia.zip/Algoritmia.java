package com.mycompany.algoritmia;

/**
 *
 * @author a2211
 */
public class Algoritmia {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
